<?php

session_start();

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['id'];

$kor = isset($_POST['kor']) ? $_POST['kor'] : 0;
$eng = isset($_POST['eng']) ? $_POST['eng'] : 0;
$math = isset($_POST['math']) ? $_POST['math'] : 0;

$total = $kor + $eng + $math;
$avg = $total / 3;

$servername = "localhost";
$username_db = "root";
$password_db = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->begin_transaction();

try {
    $check_sql = "SELECT * FROM subject WHERE id=?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $update_sql = "UPDATE subject SET kor=?, eng=?, math=?, total=?, avg=? WHERE id=?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("iiids", $kor, $eng, $math, $total, $avg, $user_id);

        if ($update_stmt->execute()) {
            echo "성적이 성공적으로 업데이트되었습니다.";
            header("Location: main.php");
        } else {
            throw new Exception("Error updating record: " . $update_stmt->error);
        }
    } else {
        $insert_sql = "INSERT INTO subject (id, kor, eng, math, total, avg, _rank) VALUES (?, ?, ?, ?, ?, ?, NULL)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("siiids", $user_id, $kor, $eng, $math, $total, $avg);

        if ($insert_stmt->execute()) {
            echo "성적이 성공적으로 입력되었습니다.";
            header("Location: main.php");
        } else {
            throw new Exception("성적을 올바르게 입력하세요. 오류: " . $insert_stmt->error);
        }
    }

$update_query = "UPDATE subject SET _rank = DENSE_RANK() OVER (ORDER BY total DESC)";
if ($conn->query($update_query) === TRUE) {
    echo "석차가 성공적으로 업데이트되었습니다.";
} else {
    echo "Error updating rank: " . $conn->error;
}

    $conn->commit();
} catch (Exception $e) {
    echo $e->getMessage();
    $conn->rollback();
}

$conn->close();
?>
