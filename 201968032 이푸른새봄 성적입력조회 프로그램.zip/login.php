<?php

session_start();

$servername = "localhost";
$username_db = "root";
$password_db = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['id'];
    $user_pw = $_POST['pw'];

    $sql = "SELECT * FROM info WHERE id='$user_id' AND pw='$user_pw'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        $_SESSION['id'] = $user_id;
        $_SESSION['name'] = $row['name'];

        header("Location: main.php");
        exit();
    } else {

        echo "아이디 또는 비밀번호가 올바르지 않습니다.";
    }
}

$conn->close();
?>