<?php

$servername = "localhost";
$username_db = "root";
$password_db = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT subject.id, info.name, subject._rank 
          FROM subject 
          LEFT JOIN info ON subject.id = info.id 
          ORDER BY subject.total DESC";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>학번</th><th>이름</th><th> 석차</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["_rank"] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No records found";
}

$conn->close();
?>
