<?php

session_start();

if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

$username = $_SESSION['name'];

$servername = "localhost";
$username_db = "root";
$password_db = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['id'];

$sql = "SELECT * FROM info WHERE id='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $user_id = $row['id'];
    $user_pw = $row['pw'];
    $user_name = $row['name'];

} else {
    echo "사용자 정보를 찾을 수 없습니다.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main 페이지</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        p {
            font-size: 1.5rem;
            color: #333;
        }

        h2 {
            margin-top: 20px;
            color: #333;
        }

        form {
            margin-top: 20px;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    

    <div class="container">
    <h2>안녕하세요, <?php echo $username; ?>님!<h2>
        <form action="grade_input.htm" method="post">
            <input type="submit" value="성적 입력">
        </form>
        <form action="grade_view.php" method="post">
            <input type="submit" value="성적 조회">
        </form>
    </div>
</body>

</html>
