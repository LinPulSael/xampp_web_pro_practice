<?php

session_start();

$servername = "localhost";
$username_db = "root";
$password_db = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username_db, $password_db, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['id'];

$query = "SELECT subject.id, info.name, subject.kor, subject.eng, subject.math, subject.total, subject.avg, subject._rank FROM subject LEFT JOIN info ON subject.id = info.id WHERE subject.id = '$user_id'";

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>학번</th><th>이름</th><th>국어</th><th>영어</th><th>수학</th><th>총점</th><th>평균</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . ($row["name"] ?? "") . "</td>"; 
        echo "<td>" . $row["kor"] . "</td>";
        echo "<td>" . $row["eng"] . "</td>";
        echo "<td>" . $row["math"] . "</td>";
        echo "<td>" . $row["total"] . "</td>";
        echo "<td>" . $row["avg"] . "</td>";
        echo "</tr>";
    }

    echo "</table>";
    echo "<form action='rank_view.php' method='post'>";
    echo "<input type='submit' value='전체 석차조회'>";
    echo "</form>";
    echo "<button onclick='history.go(-1)'>이전 화면으로</button>";

    echo "<form action='logOut.php' method='post'>";
    echo "<input type='submit' value='로그아웃'>";
    echo "</form>";
} else {
    echo "No records found";
}

$conn->close();
?>
