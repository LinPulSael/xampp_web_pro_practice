<?php
$servername = "localhost";
$username = "root";
$password = "abcd";
$dbname = "test";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $pw = $_POST["pw"];
    $name = $_POST["name"];
    $dept = $_POST["dept"];
    $tel = $_POST["tel"];

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO info (id, pw, name, dept, tel) VALUES ('$id', '$pw', '$name', '$dept', '$tel')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('회원가입이 성공적으로 완료되었습니다.');</script>";
        echo "<script>window.location.replace('index.php');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .container {
            text-align: center;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
        }

        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin: 10px 0;
            color: #555;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #3498db;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>회원가입</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="id">아이디 (학번)</label>
            <input type="text" id="id" name="id" required>
            <br>
            <label for="pw">비밀번호 </label>
            <input type="password" id="pw" name="pw" required>
            <br>
            <label for="name">이름 </label>
            <input type="text" id="name" name="name" required>
            <br>
            <label for="dept">학과 </label>
            <input type="text" id="dept" name="dept" required>
            <br>
            <label for="tel">전화번호 </label>
            <input type="text" id="tel" name="tel" required placeholder="xxx-xxxxx-xxxx">
            <br>
            <button type="submit">가입하기</button>
        </form>
    </div>
</body>

</html>
