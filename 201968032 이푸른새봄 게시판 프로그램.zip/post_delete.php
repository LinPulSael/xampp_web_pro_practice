<?php

$servername = "localhost";
$username = "root";
$password = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$post_id = $_POST["id"];

$sql = "DELETE FROM post WHERE num = $post_id";

if ($conn->query($sql) === TRUE) {
    header("Location: post_list.php");
    exit();
} else {
    echo "게시글 삭제에 실패했습니다. 오류: " . $conn->error;
}

$conn->close();
?>
