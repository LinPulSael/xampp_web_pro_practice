<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시글 목록</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .actions a {
            margin-right: 10px;
            color: #333;
        }

        .actions a:hover {
            color: #45a049;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <h1>게시글 목록</h1>
    
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "abcd";
    $dbname = "test";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM post";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>글 번호</th><th>이름</th><th>제목</th><th>자세히 보기</th><th>게시글 수정</th></tr>";
    
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["num"] . "</td>";
            echo "<td>" . $row["name"] . "</td>";
            echo "<td>" . $row["subject"] . "</td>";
    
            echo "<td class='actions'>";
            echo "<a href='post_view.php?id={$row["num"]}'>게시글 보기</a>";
            echo "</td>";
    
            echo "<td class='actions'>";
            echo "<a href='post_update.php?id={$row["num"]}'>게시글 수정</a>";
            echo "</td>";
    
            echo "</tr>";
        }
    
        echo "</table>";
    } else {
        echo "등록된 글이 없습니다.";
    }

    echo "<form action='index.php' method='get'>";
    echo "<input type='submit' value='글쓰기'>";
    echo "</form>";

    $conn->close();
    ?>
</body>
</html>
