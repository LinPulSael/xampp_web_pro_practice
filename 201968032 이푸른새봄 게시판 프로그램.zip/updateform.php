<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시글 수정</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #4caf50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <h1>게시글 수정</h1>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "abcd";
    $dbname = "test";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $post_id = $_GET["id"];

    $sql = "SELECT * FROM post WHERE num = $post_id";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            echo "<form action='post_update_process.php' method='post'>";
            echo "<input type='hidden' name='id' value='{$row["num"]}'>";
            echo "<label for='content'>내용:</label>";
            echo "<textarea name='content' id='content' rows='4' required>{$row["content"]}</textarea>";
            echo "<br>";
            echo "<input type='submit' value='수정 완료'>";
            echo "</form>";
        } else {
            echo "게시글이 없습니다.";
        }
    } else {
        echo "쿼리 실행에 실패했습니다.";
    }

    $conn->close();
    ?>
</body>

</html>
