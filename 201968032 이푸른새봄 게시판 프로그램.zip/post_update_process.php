<?php

$servername = "localhost";
$username = "root";
$password = "abcd";
$dbname = "test";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$post_id = $_POST["id"]; 
$new_content = $_POST["content"]; 

$sql = "UPDATE post SET content = '$new_content' WHERE num = $post_id";

if ($conn->query($sql) === TRUE) {
    header("Location: post_view.php?id=$post_id");
    exit();
} else {
    echo "게시글 수정에 실패했습니다. 오류: " . $conn->error;
}

$conn->close();
?>
