<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시글 보기</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        textarea {
            width: 100%;
            height: 100px; 
        }
    </style>
</head>

<body>
    <h1>게시글 보기</h1>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "abcd";
    $dbname = "test";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $post_id = $_GET["id"];

    $sql = "SELECT * FROM post WHERE num = $post_id";
    $result = $conn->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();

            echo "<table>";
            echo "<tr><th>글 번호</th><td colspan='2'>" . $row["num"] . "</td></tr>";
            echo "<tr><th>제목</th><td colspan='2'>" . $row["subject"] . "</td></tr>";
            echo "<tr><th>아이디</th><td>" . $row["id"] . "</td>";
            echo "<th>이름</th><td>" . $row["name"] . "</td>";
            echo "<th>닉네임</th><td>" . $row["nick"] . "</td></tr>";
            echo "<tr><th>내용</th><td colspan='5'>" . $row["content"] . "</td></tr>";
            echo "</table>";

            echo "<a href='updateform.php?id={$row["num"]}'><input type='button' value='게시글 수정'></a>";

            echo "<form action='post_delete.php' method='post'>";
            echo "<input type='hidden' name='id' value='{$row["num"]}'>";
            echo "<input type='submit' value='게시글 삭제'>";
            echo "</form>";

            echo "<button onclick='window.print()'>게시글 인쇄</button>";

            echo "<form action='post_list.php' method='get'>";
            echo "<input type='submit' value='게시글 목록 이동'>";
            echo "</form>";
        } else {
            echo "게시글이 없습니다.";
        }
    } else {
        echo "쿼리 실행에 실패했습니다.";
    }

    $conn->close();
    ?>
</body>

</html>
