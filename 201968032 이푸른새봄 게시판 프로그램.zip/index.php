<?php
$servername = "localhost";
$username = "root";
$password = "abcd";
$dbname = "test";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $nickname = $_POST["nickname"]; 
    $subject = $_POST["subject"];
    $content = $_POST["content"];

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO post (id, name, nick, subject, content) VALUES ('$id', '$name', '$nickname', '$subject', '$content')";

    if ($conn->query($sql) === TRUE) {
        header("Location: post_list.php");
        exit();
    } else {
        echo "게시글 작성에 실패했습니다. 오류: " . $conn->error;
    }

    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>게시글 작성</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }

        h1 {
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"], input[type="button"] {
            background-color: #4caf50;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover, input[type="button"]:hover {
            background-color: #45a049;
        }

        
    </style>
</head>
<body>
    <h1>게시판 프로그램</h1>
    <form action="" method="post">
        <label for="id" > 아이디 : </label>
        <input type="text" name="id" id="id" required>
        <label for="name">이름:</label>
        <input type="text" name="name" id="name" required>
        <br>
        <label for="nickname">닉네임:</label>
        <input type="text" name="nickname" id="nickname" required> 
        <br>
        <label for="subject">제목:</label> 
        <input type="text" name="subject" id="subject" required>
        <br>
        <label for="content">내용:</label>
        <textarea name="content" id="content" rows="4" required></textarea>
        <br>
        <input type="submit" value="게시글 작성">
        <a href="post_list.php"><input type="button" value="게시글 목록"></a>
    </form>

</body>
</html>
